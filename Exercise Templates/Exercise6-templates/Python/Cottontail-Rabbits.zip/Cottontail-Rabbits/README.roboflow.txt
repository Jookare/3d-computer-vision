
Cottontail-Rabbits - v1 Augmented Data
==============================

This dataset was exported via roboflow.ai on July 24, 2021 at 5:27 AM GMT

It includes 2009 images.
Cottontail-Rabbit are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 30 versions of each source image:
* Random brigthness adjustment of between -25 and +25 percent
* Random exposure adjustment of between -25 and +25 percent


