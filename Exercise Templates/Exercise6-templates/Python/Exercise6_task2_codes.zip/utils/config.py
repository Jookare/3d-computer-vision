EPS = 1e-6

GRID_SIZE   = 7   # Divide each image into a SxS grid   S
N_BBOX      = 1   # Number of bounding boxes to predict B 
N_CLASSES   = 1   # Number of classes in the dataset    C
